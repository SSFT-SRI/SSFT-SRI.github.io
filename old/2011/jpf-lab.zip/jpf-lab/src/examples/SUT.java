public class SUT {
  int data; // should be within [0..42]

  void setData(int d){
    data = d;
  }

  public static void main(String[] args){
    SUT sut = new SUT();
    sut.setData( 42);  // should not trigger violation
    sut.setData(-42);  // should trigger violation
  }
}

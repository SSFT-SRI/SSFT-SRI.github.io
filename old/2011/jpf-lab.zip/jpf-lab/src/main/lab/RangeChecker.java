package lab;

import gov.nasa.jpf.*;                // don't do '*' imports
import gov.nasa.jpf.search.*;
import gov.nasa.jpf.jvm.*;
import gov.nasa.jpf.jvm.bytecode.*;
import gov.nasa.jpf.util.*;


public class RangeChecker extends PropertyListenerAdapter {
  FieldSpec fieldSpec;
  int min, max;
  String error;

  public RangeChecker (Config conf){
    String spec = conf.getString("rc.field");
    fieldSpec = FieldSpec.createFieldSpec(spec);
    min = conf.getInt( "rc.min", Integer.MIN_VALUE);
    max = conf.getInt( "rc.max", Integer.MAX_VALUE);
  }

  protected boolean isRelevantField(PUTFIELD insn){
    return fieldSpec.matches(insn.getFieldInfo());
  }

  protected boolean isValueOutOfRange(PUTFIELD insn){
    int v = (int)insn.getLastValue();
    return (v < min) || (v > max);
  }

  protected void storeError (JVM vm, PUTFIELD insn){
    ThreadInfo ti = vm.getLastThreadInfo();
    FieldInfo fi = insn.getFieldInfo();

    error = String.format( "field %s=%d out of range in thread %s at %s",
        fi.getFullName(), insn.getLastValue(), ti.getName(), insn.getSourceLocation());
  }

  @Override 
  public void instructionExecuted(JVM vm){
    Instruction insn = vm.getLastInstruction();
    if (insn instanceof PUTFIELD){
      PUTFIELD put = (PUTFIELD)insn;
      if (isRelevantField(put)){
         if (isValueOutOfRange(put)){
           storeError(vm, put);
           vm.breakTransition();
         }
      }
    }
  }

  @Override 
  public boolean check(Search search, JVM vm) {
    return (error == null);
  }

  @Override
  public String getErrorMessage(){
    return error;
  }
}

theory Automation
imports Complex_Main
begin

sledgehammer_params [provers = e spass vampire remote_z3, timeout = 10]


section{* Standard Proof Automation *}


subsection{* Simplification & Co *}

lemma "length(xs @ xs) = 2 * length xs"
by simp

text{* Beyond simp: *}

lemma "\<lbrakk> \<forall>xs\<in>A. length xs \<le> 3;  \<forall>xs\<in>B. length xs \<ge> 2 \<rbrakk>
  \<Longrightarrow> \<forall>xs \<in> A \<inter> B. length xs \<in> {2,3}"
apply simp
try0
by fastforce


subsection{* Logic & sets *}

lemma "((P \<longrightarrow> Q) \<longrightarrow> P) \<longrightarrow> P"
by blast

lemma "(\<Union>i \<in> I \<inter> J. M i) \<subseteq> (\<Union>i\<in>I. M i) \<inter> (\<Union>i\<in>J. M i)"
by blast


subsection{* Arithmetic *}

lemma "\<forall> (k::nat) > 119. \<exists>i j. k = 9*i + 16*j"
by presburger

lemma "(x::int)^3 - x^2 - 5*x - 3 = 0 \<longleftrightarrow> (x = 3 \<or> x = -1)"
by algebra



section {* Sledgehammer *}

lemma "xs = Nil \<or> xs = Cons (hd xs) (tl xs)"
try0 (* fails *)
sledgehammer
sorry

lemma "y = x * k \<Longrightarrow> gcd (x\<Colon>int) y = abs x"
sledgehammer [isar_proof]
sorry

lemma "a # xs = ys @ [a] \<Longrightarrow> P"
oops


section {* Quickcheck *}

lemma "rev (xs @ ys) = rev xs @ rev ys"
oops

lemma "map (f o g) xs = map g (map f xs)"
oops


section {* Nitpick *}

lemma "(R \<union> S)^* = R^* \<union> S^*"
nitpick
oops

lemma "acyclic R \<Longrightarrow> acyclic S \<Longrightarrow> acyclic(R \<union> S)"
nitpick
oops



subsection {* Quantifiers *}

text {* Typical student errors:
  Existential and Universal Quantifiers can be swapped...
  ... but not this way. *}

lemma "(\<forall>x. \<exists>y. P x y) \<longrightarrow> (\<exists>y. \<forall>x. P x y)"
oops

lemma "(\<forall>x :: nat. \<exists>y :: nat. P x y) \<longrightarrow> (\<exists>y. \<forall>x. P x y)"
(*quickcheck -- fails, because the natural numbers are infinite *)
(*nitpick only finds a potential one *)
quickcheck
nitpick
oops


text{* More numeric curiosities: *}

definition prime :: "nat \<Rightarrow> bool" where
"prime p \<longleftrightarrow> (1 < p \<and> (\<forall>m<p. p mod m = 0 \<longrightarrow> m = 1))"

lemma "prime(n^2 + n + 41)"
quickcheck
oops

lemma "\<forall>n<40. prime(n^2 + n + 41)"
by eval

end

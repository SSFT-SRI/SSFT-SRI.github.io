theory Lambda
imports Main
begin

section "Lambda terms with alpha/beta/eta equivalence"

term "(\<lambda>x. x s) a"

lemma "(\<lambda>x. x) = (\<lambda>y. y)" by (rule refl)

section "Church Numerals"

definition
  "c_0 \<equiv> \<lambda>f x. x"

definition
  "c_1 \<equiv> \<lambda>f x. f x"

definition
  "c_2 \<equiv> \<lambda>f x. f (f x)"

definition
  "c_3 \<equiv> \<lambda>f x. f (f (f x))"

definition
  "succ \<equiv> \<lambda>n f x. f (n f x)"

definition
  "add \<equiv> \<lambda>m n f x. m f (n f x)"

definition
  "mult \<equiv> \<lambda>m n f x. m (n f) x"


section "Some properties/Unfolding definitions"

lemma "c_0 = (\<lambda>f x. x)"
  apply (unfold c_0_def)
  apply (rule refl)
  done

lemma "succ (succ c_0) = c_2"
  apply (unfold succ_def c_0_def c_2_def)
  apply (rule refl)
  done

lemma "add c_2 c_2 = succ c_3"
  apply (unfold add_def succ_def c_3_def c_2_def)
  apply (rule refl)
  done

lemma "add x c_0 = x"
  apply (unfold add_def c_0_def)
  apply (rule refl)
  done
  
lemma "mult c_1 x = x"
  apply (unfold mult_def c_1_def)
  apply (rule refl)
  done
  
end

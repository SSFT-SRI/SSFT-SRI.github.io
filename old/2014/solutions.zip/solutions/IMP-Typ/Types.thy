header "A Typed Language"

theory Types imports Complex_Main begin

subsection "Arithmetic Expressions"

datatype val = Iv int | Rv real

type_synonym name = string
type_synonym state = "name \<Rightarrow> val"

datatype aexp =  Ic int | Rc real | V name | Plus aexp aexp

inductive taval :: "aexp \<Rightarrow> state \<Rightarrow> val \<Rightarrow> bool" where
"taval (Ic i) s (Iv i)" |
"taval (Rc r) s (Rv r)" |
"taval (V x) s (s x)" |
"taval a1 s (Iv i1) \<Longrightarrow> taval a2 s (Iv i2)
 \<Longrightarrow> taval (Plus a1 a2) s (Iv(i1+i2))" |
"taval a1 s (Rv r1) \<Longrightarrow> taval a2 s (Rv r2)
 \<Longrightarrow> taval (Plus a1 a2) s (Rv(r1+r2))" 

inductive_cases [elim!]:
  "taval (Ic i) s v"  "taval (Rc i) s v"
  "taval (V x) s v" 
  "taval (Plus a1 a2) s v"

(* 
  taval is written as a relation. Define a function taval' instead
  that performs the same computation, but returns None if taval returns
  False and returns "Some v" if "taval a s v" is True: 

primrec taval' :: "aexp \<Rightarrow> state \<Rightarrow> val option" where
*)

(* Prove correctness of taval' with respect to taval: *)
lemma taval_taval':
  "taval a s v \<longleftrightarrow> taval' a s = Some v"
  oops
    
subsection "Boolean Expressions"

datatype bexp = B bool | Not bexp | And bexp bexp | Less aexp aexp

inductive tbval :: "bexp \<Rightarrow> state \<Rightarrow> bool \<Rightarrow> bool" where
"tbval (B bv) s bv" |
"tbval b s bv \<Longrightarrow> tbval (Not b) s (\<not> bv)" |
"tbval b1 s bv1 \<Longrightarrow> tbval b2 s bv2 \<Longrightarrow> tbval (And b1 b2) s (bv1 & bv2)" |
"taval a1 s (Iv i1) \<Longrightarrow> taval a2 s (Iv i2) \<Longrightarrow> tbval (Less a1 a2) s (i1 < i2)" |
"taval a1 s (Rv r1) \<Longrightarrow> taval a2 s (Rv r2) \<Longrightarrow> tbval (Less a1 a2) s (r1 < r2)"

(* Do the same for tbval: define a function tbval' that returns an option
  value, and prove its correctnes wrt to tbval. You may have to introduce
  similar automation setup to taval. *)

end
header "A Typed Language"

theory Types_Solution imports Complex_Main begin

subsection "Arithmetic Expressions"

datatype val = Iv int | Rv real

type_synonym name = string
type_synonym state = "name \<Rightarrow> val"

datatype aexp =  Ic int | Rc real | V name | Plus aexp aexp

inductive taval :: "aexp \<Rightarrow> state \<Rightarrow> val \<Rightarrow> bool" where
"taval (Ic i) s (Iv i)" |
"taval (Rc r) s (Rv r)" |
"taval (V x) s (s x)" |
"taval a1 s (Iv i1) \<Longrightarrow> taval a2 s (Iv i2)
 \<Longrightarrow> taval (Plus a1 a2) s (Iv(i1+i2))" |
"taval a1 s (Rv r1) \<Longrightarrow> taval a2 s (Rv r2)
 \<Longrightarrow> taval (Plus a1 a2) s (Rv(r1+r2))" 

inductive_cases [elim!]:
  "taval (Ic i) s v"  "taval (Rc i) s v"
  "taval (V x) s v"
  "taval (Plus a1 a2) s v"

primrec taval' where
  "taval' (Ic i) _ = Some (Iv i)" |
  "taval' (Rc r) _ = Some (Rv r)" |
  "taval' (V x) s = Some (s x)" |
  "taval' (Plus a1 a2) s = (case (taval' a1 s, taval' a2 s) of
    (Some (Iv i1), Some (Iv i2)) \<Rightarrow> Some (Iv (i1 + i2))
  | (Some (Rv r1), Some (Rv r2)) \<Rightarrow> Some (Rv (r1 + r2))
  | _ \<Rightarrow> None)"

lemma taval_taval':
  "taval a s v \<longleftrightarrow> taval' a s = Some v"
  by (induct a arbitrary: v)
     (auto intro: taval.intros split: option.splits val.splits)
  
lemma taval_tabal'_longer: 
  "taval a s v \<longleftrightarrow> taval' a s = Some v"
proof (induct a arbitrary: v)
  case (Plus a1 a2)
  show ?case
  proof (cases "taval' a1 s")
    case None with Plus
    show ?thesis by auto 
  next
    case (Some v1)
    note v1 = this
    show ?thesis
    proof (cases "taval' a2 s")
      case None with Plus
      show ?thesis by (auto split: val.splits option.splits)
    next
      case (Some v2)
      with v1 Plus
      show ?thesis 
        by (auto intro: taval.intros split: val.splits)
    qed
  qed
qed (auto intro: taval.intros)[3]
  
subsection "Boolean Expressions"

datatype bexp = B bool | Not bexp | And bexp bexp | Less aexp aexp

inductive tbval :: "bexp \<Rightarrow> state \<Rightarrow> bool \<Rightarrow> bool" where
"tbval (B bv) s bv" |
"tbval b s bv \<Longrightarrow> tbval (Not b) s (\<not> bv)" |
"tbval b1 s bv1 \<Longrightarrow> tbval b2 s bv2 \<Longrightarrow> tbval (And b1 b2) s (bv1 & bv2)" |
"taval a1 s (Iv i1) \<Longrightarrow> taval a2 s (Iv i2) \<Longrightarrow> tbval (Less a1 a2) s (i1 < i2)" |
"taval a1 s (Rv r1) \<Longrightarrow> taval a2 s (Rv r2) \<Longrightarrow> tbval (Less a1 a2) s (r1 < r2)"

inductive_cases tbval_cases:
  "tbval (B b) s v"
  "tbval (Not b) s v"
  "tbval (And b1 b2) s v"
  "tbval (Less a1 a2) s v"

primrec tbval' :: "bexp \<Rightarrow> state \<Rightarrow> bool option" where
  "tbval' (B bv) _ = Some bv" |
  "tbval' (Not b) s = (case tbval' b s of None \<Rightarrow> None | Some v \<Rightarrow> Some (~v))" |
  "tbval' (And b1 b2) s = (case (tbval' b1 s, tbval' b2 s) of
     (Some v1, Some v2) \<Rightarrow> Some (v1 \<and> v2)
   | _ \<Rightarrow> None)" | 
  "tbval' (Less a1 a2) s = (case (taval' a1 s, taval' a2 s) of 
     (Some (Iv v1), Some (Iv v2)) \<Rightarrow> Some (v1 < v2)
   | (Some (Rv v1), Some (Rv v2)) \<Rightarrow> Some (v1 < v2)
   | _ \<Rightarrow> None)"

lemma tbval_tbval':
  "tbval b s v \<longleftrightarrow> tbval' b s = Some v"
  by (induct b arbitrary: v)
     (auto elim!: tbval_cases intro: tbval.intros
           simp: taval_taval'
           split: option.splits val.splits)

end
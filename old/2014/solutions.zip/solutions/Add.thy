theory Add
imports Main
begin

fun add where
  "add 0 y = y" |
  "add (Suc x) y = Suc (add x y)"

lemma "add x y = x + y"
  by (induct x) auto

lemma "add x (add y z) = add (add x y) z"
  by (induct x) auto

lemma add_0 [simp]: "add x 0 = x"
  by (induct x) auto

lemma add_Suc [simp]: "add x (Suc y) = Suc (add x y)"
  by (induct x) auto

lemma "add x y = add y x"
  by (induct x) (auto)

end
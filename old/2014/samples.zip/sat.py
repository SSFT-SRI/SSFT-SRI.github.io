from z3 import *


tie, shirt = Bools('tie shirt')

print """tie, shirt = Bools('tie shirt')"""
sys.stdin.readline()


print """solve (And([Or(tie, shirt), Or(Not(tie),shirt), Or(Not(shirt),Not(tie))]))"""
sys.stdin.readline()
solve (And([Or(tie, shirt), Or(Not(tie),shirt), Or(Not(shirt),Not(tie))]))
sys.stdin.readline()

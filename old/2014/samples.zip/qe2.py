from z3 import *

x, u, v = Ints('x u v')
stamp = ForAll([x],
	       Implies(x >= 25,
		       Exists([u,v],
			      And(u >= 0, v >= 0, x == 3*x + 5*v))))

print stamp

print Tactic('qe').apply(stamp)


sys.stdin.readline()

I = IntSort()
R = Function('R', I, I, BoolSort())


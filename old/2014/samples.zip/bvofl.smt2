
(declare-const a (_ BitVec 4))
(declare-const b (_ BitVec 4))
(assert (not (iff (bvumul_noovfl a b) (= ( bv2int (bvmul a b)) (* (bv2int a) (bv2int b))))))
(check-sat)
(get-model)


(set-logic HORN)
(declare-datatypes () ((Parity (Even) (Odd))))
(declare-fun Color (Bool Parity) Bool)
(declare-fun Shuffle (Bool Bool Parity Parity) Bool)
(declare-fun Flip (Parity Parity) Bool)

(assert (Flip Even Odd))
(assert (Flip Odd Even))

(assert (Color true Even))
(assert (forall ((b Bool) (i Parity) (j Parity)) 
	(=> (and (Flip i j) (Color b i)) (Color (not b) j))))

(assert (forall ((n Parity)) (=> (Color false n) (Shuffle true false Even n))))

(assert (forall ((d1 Bool) (d2 Bool) (i Parity) (j Parity) (i1 Parity) (j1 Parity) (c1 Bool) (c2 Bool))
           (=> (and (Shuffle d1 d2 i j) (Color c1 i) (Color c2 j) (Flip i i1) (Flip j j1))
                     (Shuffle c1 c2 i1 j1))))

(assert (forall ((d1 Bool) (d2 Bool) (i Parity) (j Parity) (i1 Parity) (i2 Parity) (c1 Bool) (c2 Bool))
           (=> (and (Shuffle d1 d2 i j) (Color c1 i) (Color c2 i1) (Flip i i1) (Flip i1 i2))
                     (Shuffle c1 c2 i2 j))))

(assert (forall ((d1 Bool) (d2 Bool) (i Parity) (j Parity) (j1 Parity) (j2 Parity) (c1 Bool) (c2 Bool))
           (=> (and (Shuffle d1 d2 i j) (Color c1 j) (Color c2 j1) (Flip j j1) (Flip j1 j2))
                     (Shuffle c1 c2 i j2))))

(assert (forall ((c1 Bool) (c2 Bool) (i Parity) (j Parity))
         (=> (Shuffle c1 c2 i j) (not (= c1 c2)))))

(check-sat)
(get-model)
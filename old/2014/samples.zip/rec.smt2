(set-logic HORN)

(declare-fun IsNat (Int) Bool)
(assert (IsNat 0))
(assert (forall ((x Int)) (=> (IsNat x) (IsNat (+ x 1)))))
;(assert (IsNat (- 1)))
(assert (not (IsNat (- 1))))
(check-sat)
(get-model)



;;;;;;; (assert (not (IsNat (~ 1))))


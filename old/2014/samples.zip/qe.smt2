(simplify (forall ((x Int)) (exists ((y Int)) (> y (+ x 2)))))
; true

(push)
(assert (forall ((x Int)) (exists ((y Int)) (> y (+ x 2)))))
(apply qe)
(pop)
(simplify (forall ((x Int)) (> 0 (+ x 2))))
; false

(push)
(assert (forall ((x Int)) (> 0 (+ x 2))))
(apply qe)
(pop)

(push)
(assert
   (exists ((l Int)) (forall ((x Int)) (implies (>= x l)
    (exists ((u Int) (v Int)) (and (>= u 0) (>= v 0) (= x (+ (* 3 u) (* 5 v)))))))))
(apply qe)
(pop)
; true


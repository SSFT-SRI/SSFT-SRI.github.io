(declare-fun IsNat (Int) Bool)
(assert (IsNat 0))
(assert (forall (x Int) 
     (iff (IsNat (+ x 1)) 
          (or (= x 0) (IsNat x)))))
(assert (IsNat (~ 1)))
(check-sat)
; unknown
(model)

(declare-const x Real)
(declare-const y Real)

(echo "(simplify (>= x (+ x y)))")
(simplify (>= x (+ x y)))

(declare-const a Bool)
(declare-const b Bool)
(echo "(simplify (and a (or a b)))")
(simplify (and a (or a b)))

(echo "(simplify (or (> x y) (>= x y)))")
(simplify (or (> x y) (>= x y)))

;(push)
;(assert (and a (or a b)))
;(apply propagate-values)
;(pop)


;(push)
;(assert (or (> x y) (>= x y)))
;(apply ctx-solver-simplify)
;(pop)


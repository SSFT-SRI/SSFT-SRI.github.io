# Use I as an alias for IntSort()
I = IntSort()
B = BoolSort()
# A is an array from integer to integer
A = Array('A', I, B)
A2 = Array('A2', I, B)
x = Int('x')
print A[x]
print Select(A, x)
#print Store(A, x, 10)
#print simplify(Select(Store(A, 2, x+1), 2))
def Union(X,Y):
    args = [X,Y]
    _args = (Ast * len(args))()
    for i in range(len(args)):
        _args[i] = args[i].as_ast()
    r = Z3_mk_set_union(X.ctx.ref(), len(args), _args)
    return ArrayRef(r, X.ctx)
def Intersect(X,Y):
    args = [X,Y]
    _args = (Ast * len(args))()
    for i in range(len(args)):
        _args[i] = args[i].as_ast()
    r = Z3_mk_set_intersect(X.ctx.ref(), len(args), _args)
    return ArrayRef(r, X.ctx)
        
print Union(A,A2)
prove(Implies(Union(A,A2) == A, Intersect(A,A2) == A2))



(set-logic HORN)
(declare-fun R (Int Int) Bool)

(assert (forall ((x Int)) (=> (> x 100) (R x (- x 10)))))

(assert (forall ((x Int) (y Int) (z Int))
	  (=> (and (<= x 100) (R (+ x 11) y) (R y z)) (R x z))))

(assert (forall ((x Int) (y Int))
	  (=> (and (R x y) (<= x 100)) (= y 91))))

(check-sat)
(get-model)


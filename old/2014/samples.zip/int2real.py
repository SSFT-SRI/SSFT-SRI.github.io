from z3 import *
x = BitVecVal(2,8)
y = Real('y')
print x
print x.ctx.ref()
print x.as_ast()

def to_int(x):
    return ArithRef(Z3_mk_bv2int(x.ctx_ref(), x.as_ast(), 0), x.ctx)

print to_int(x) + y

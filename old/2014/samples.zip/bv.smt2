  (define-fun is-power-of-two ((x (_ BitVec 4))) Bool (= #x0 (bvand x (bvsub x #x1))))
  (declare-const a (_ BitVec 4))
  (assert (not (iff (is-power-of-two a) 
                    (or (= a #x0) (= a #x1) (= a #x3) (= a #x4) (= a #x8))))) 
  (check-sat)  
; sat
  (get-model)
; ("model" "a -> #x2")

  (assert (not (iff (is-power-of-two a) 
                    (or (= a #x0) (= a #x1) (= a #x2) (= a #x4) (= a #x8))))) 
  (check-sat)
; unsat

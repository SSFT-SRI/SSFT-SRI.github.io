
(declare-const a (_ BitVec 4))
(declare-const b (_ BitVec 4))
(define-fun bv2signed ((x (_ BitVec 4))) Int
      (let ((xI (bv2int x)))
      (ite (bvsge x #x0) xI (- xI 16))))

(assert (not (iff (bvule a b) (bvsle a b))))
(check-sat)
(get-model)
(eval (bv2int a))
(eval (bv2int b))
(eval (bv2signed a))
(eval (bv2signed b))

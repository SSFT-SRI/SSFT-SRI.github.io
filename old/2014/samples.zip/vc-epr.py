from z3 import *

Cell = DeclareSort('Cell')
Next = Function('Next*', Cell, Cell, BoolSort())
data = Array('data', Cell, IntSort())

def NextP(x,y):
    return And(x != y, Next(x,y))
    
def NextB(x,y):
    z = FreshCell()
    return And(NextP(x,y), ForAll(z, Implies(NextP(x,z),Next(y,z))))


# d = c->next
#   forall e. Next!(c, e) => Q[e/d]
#   - leaving out alloc(c)
def wp_d_c_next(d, c, Q):
    e = FreshCell()
    return ForAll(e, Implies (NextB(c, e), substitute(Q, (d, e))))

# c = null
#   Q[lambda a, b: next(a,b) & (next(a,c) -> next(b,c))/next]
def wp_next_null(c, Q):
    fn = lambda a,b: And(Next(a,b), Implies(Next(a,c), Next(b,c)))
    return replace(Q, fn)

# c->next = d
#   Q[next(a,b) or (next(a,c) and next(d, b))]
#   - leaving out alloc(c)
def wp_c_next_d(c, d, Q):
    fn = lambda a,b: Or(Next(a,b), And(Next(a,c),Next(d, b)))
    return replace(Q, fn)
    

# c->data = val
#   Q[store(data, c, val)/data]
#   - leaving out alloc(c)
def wp_set_data(data, c, val, Q):
    return substitute(Q, (data, Update(data, c, val)))

# d = c
def wp_d_c(d, c, Q):
    return substitute(Q, (d, c))


def is_next(t):
    return is_app(t) and t.decl().eq(Next)

def replace(t, fn):
    def rep(t):
	if is_next(t):
	    a = t.arg(0)
	    b = t.arg(1)
	    return fn(a,b)	
	if is_app(t):
	    return t.decl()([rep(arg) for arg in t.args()])
	if is_quantifier(t):
	    vars = [Const(t.var_name(i), t.var_sort(i)) for i in range(t.num_vars())]
	    vars.reverse()
	    body = substitute_vars(t.body(), *vars)
	    if t.is_forall():
		return ForAll(vars, rep(body))
	    else:
		return Exists(vars, rep(body))
	assert False
	return None
    return rep(t)

counter = 0
def FreshCell():
    global counter
    counter += 1
    id = "e%d" % counter
    return Const(id, Cell)

# while (c) { c->data = 0; c = c->next; }
#   assert (forall d . next*(c_0, d) => d->data = 0 or d = null)

# I := (next*(c_0, c) && forall d . next*(c_0, d) & next+(d, c) => d->data = 0)

c0 = Const('c0', Cell)
c  = Const('c', Cell)
d  = Const('d', Cell)
e  = Const('e', Cell)
null = Const('null', Cell)
I = And(Next(c0, c),
	ForAll(d, Implies(And(Next(c0, d), NextP(d, c)), Select(data, d) == 0)))

Ax0 = ForAll([c],     Next(c,c))
Ax1 = ForAll([c,d,e], Implies(And(Next(c,d),Next(d,e)), Next(c,e)))
Ax2 = ForAll([c,d],   Implies(And(Next(c,d),Next(d,c)), c == d))
Ax3 = ForAll([c,d,e], Implies(And(Next(c,d),Next(c,e)),
			      Or(Next(d,e),Next(e,d))))
Ax = And(Ax0,Ax1,Ax2,Ax3)

vc = Implies(And(I, c != null), wp_set_data(data, c, 1, wp_d_c_next(c, c, I)))

print vc
print Ax

prove(Implies(Ax, vc))

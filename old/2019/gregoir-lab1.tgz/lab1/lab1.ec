(* Ctr c n : evaluate the next line *)
(* Ctr c u : backtract the previous line *)
(* Ctr enter : go to the line pointer by the cursor *)

require import AllCore Distr.


(* *********************************************************** *)
(* Small examples to deal with logic                           *)
(* *********************************************************** *)

(* using the smt tactic *)
lemma tauto (a b : bool) : (a => b) => a => a /\ b.
proof. (* for presentation purpose *)
  smt(). 
qed.   (* save the proof *)

(* Doing it, step by step *)
lemma tauto1 (a b : bool) : (a => b) => a => a /\ b.
proof. 
  move=> himp.
  move=> ha.
  split.
  + apply ha.
  apply himp.    
  apply ha.
qed.

(* Nicer version *)
lemma tauto2 (a b : bool) : (a => b) => a => a /\ b.
proof. 
  move=> himp ha; split => //.  (* => // : try to trivially solve sub-goals *)
  by apply himp.                (* by t : stands for t => // and ensures that all sub-goals are solved *)
qed.

(* If you don't want to prove a goal you can use the admit tactic *)
lemma tauto3 (a b : bool) : (a => b) => a => a /\ b.
proof. 
  move=> himp ha; split.
  + admit.
  admit.
qed.

(* *********************************************************** *)
(* Using print and search                                      *)
(* *********************************************************** *)

print Int.         
print Int.(+).
print natind.

search Int.(+) Int.( * ).   (* search all lemma containing Int.(+) and Int.( * ) *)
search (_ * (_ + _))%Int.   (* search all lemma containing a sub-expression of the form (_ * (_ + _))%Int. *)
search (_ * (_ + _))%Int (_ * _ + _ * _)%Int. 

(* *********************************************************** *)
(* Playing with pRHL                                           *)
(* *********************************************************** *)

module M1 = {
  proc f (x:int) : int = {
     var y, z : int;
     y <- x + 3;
     z <- x + 5;
     return (x + y) * (y + z);
  }

  proc g (w:int) : int = {
    var y, z : int;
    y <- w;
    z <- w + 5;
    return (w + (y + 3)) * ((y + 3) + z); 
  }
}.

(* proc, wp and skip, try to understand their effects  *)
equiv M1_f_g : M1.f ~ M1.g : x{1} = w{2} ==> ={res}.
proof.
  proc.  (* enter into function *)
  (* Try the following tactics:
     wp 2 1.
     wp 1 2.
     wp 1 1.
     wp 2 0.
     wp 0 2.
   *)
   wp.
   skip.
   (* To finish your proof. *)
   by move=> />.   
qed.

module M2 = {
  proc f (x:int) : int * int * int = {
     var y, z : int;
     y <- x + 3;
     z <- x + 5;
     return (x, y, z);
  }

  proc g (x:int) : int * int * int = {
    var y, z, t: int;
    t <- 5; 
    y <- x + 3;
    z <- x + t;
    return (x,y,z);
  }
}.

(* seq tactic *)

equiv M2_f_g : M2.f ~ M2.g : ={x} ==> ={res}.
proof.
  proc.
  seq 1 2: (={x,y} /\ t{2} = 5).
  (* finish the proof (i.e remove admit), using only the previous tactics *)
  + admit.
  admit.
qed.

(* Using auto tactic *)

equiv M2_f_g' : M2.f ~ M2.g : ={x} ==> ={res}.
proof.
  proc.
  seq 1 2: (={x,y} /\ t{2} = 5).
  (* finish the proof (i.e remove admit) *)
  + auto.
  auto.
qed.

equiv M2_f_g'' : M2.f ~ M2.g : ={x} ==> ={res}.
proof.
  proc.
  seq 1 2: (={x,y} /\ t{2} = 5); auto.  (* t1; t2: apply t1 then t2 on all subgoal *)
qed.

(* Dealing with global variables *)

module Mg = {
  var x:int
 
  proc f () : int = {
    return 3;
  } 

  proc g () : int = {
    return x;
  }

  proc main1() : int = {
    var r : int;
    r <@ f();  (* <@ is the syntax for calling a function *)
    return r;
  }

  proc main2() : int = {
    var r : int;
    x <- 3;
    r <@ g();
    return r;
  }
}.

equiv Mg_f_g : Mg.f ~ Mg.g : Mg.x{2} = 3 ==> ={res}.
proof.
  admit.
qed.

equiv Mg_main1_2 : Mg.main1 ~ Mg.main2: true ==> ={res}.
proof.
  proc.
  call (_: Mg.x{2} = 3 ==> ={res}).
  + apply Mg_f_g.
  admit.
qed.

equiv Mg_main1_2_v1 : Mg.main1 ~ Mg.main2: true ==> ={res}.
proof.
  proc.
  call Mg_f_g.
  admit.
qed.

(* using inline tactic *)
equiv Mg_main1_2_v2 : Mg.main1 ~ Mg.main2: true ==> ={res}.
proof.
  proc.
  inline{1} Mg.f.
  inline{2} Mg.g.
  admit.
qed.

equiv Mg_main1_2_v3 : Mg.main1 ~ Mg.main2: true ==> ={res}.
proof.
  proc.
  inline *.
  admit.
qed.

(* Using the if{1}; if{2} and if tactic *)

module M3 = {
  proc f (x:int) : int = {
    if (0 <= x) {
      x <- x + 1;
    } else {
      x <- x + 2;
    }
    return x;
  }

  proc nf (x:int) : int = {
    if (x < 0) {
      x <- x + 2;
    } else {
      x <- x + 1;
    }
    return x;
  }
  
}.

equiv M3_f_g : M3.f ~ M3.f : ={x} ==> ={res}.
proof.
  proc.
  if.
  + admit.
  + admit.
  admit.
qed.

equiv M3_f_g_1 : M3.f ~ M3.nf : ={x} ==> ={res}.
proof.
  proc.
  if{1}.
  + if{2}.
    + exfalso. 
      admit.
    admit.
  if{2}.
  + admit.
  exfalso.
  admit.
qed.

(* Using the case and rcondt, rcondf tactic *)
equiv M3_f_g_2 : M3.f ~ M3.nf : ={x} ==> ={res}.
proof.
  proc.
  case: (0 <= x{1}).
  + rcondt{1} 1.
    + move=> &m. (* memory name should start with a & *)
      admit.
    rcondf{2} 1.
    + move=> &m.
      admit.
    admit.
  rcondf{1} 1.    
  + admit.
  rcondt{2} 1.
  + admit.
  admit.
qed.

(* rcondt, rcondf on loop *)

module M4 = {
  proc f (x:int) = {
    var r : int <- 0;
    var i : int <- 0;
    while (i < 2) {
      r <- r + x;
      i <- i + 1;
    }
    return r;
  }

  proc g (x:int) = {
    return (x + x);
  }
}.

equiv M4_f_g : M4.f ~ M4.g : ={x} ==> ={res}.
proof.
  proc.
  rcondt{1} 3.
  + move=> &m.
    wp.
    skip.
    move=> &hr ?. 
    done.
  rcondt{1} 5.
  + move => &m.
    auto.
  rcondf{1} 7.
  + admit.
  admit.
qed.

(* while loop *)

module M5 = {
  proc f (x:int) : int = {
    var i : int <- 0;
    while (i < 10) {
      x <- x + i;
      i <- i + 1;
    }
    return x;
  }  
}.

equiv M5_f_f : M5.f ~ M5.f : ={x} ==> ={res}.
proof.
  proc.
  while (={x, i}).
  + admit.
  admit.
qed.

module M6 = {
  proc f (x:int) : int = {
    var i : int = 0;
    while (i < 10) {
      x <- x + 3;
      i <- i + 1;
    }
    return x;
  } 
}.

module M7 = {
 
  var z : int 

  proc f (x:int) : int = {
    var i : int = 0;
    while (i < 10) {
      x <- x + z;
      i <- i + 1;
    }
    return x;
  }  
}.

(* What is the precondition that will ensure that f and g return the same result ? 
   Fill the dots
*)

equiv M6f_M7f : M6.f ~ M7.f : ={x} /\ M7.z{2} = 3 ==> ={res}.
proof.
  proc.
  while (={x,i} /\ M7.z{2} = 3).
  + admit.
  admit.
qed.

(* Dealing with adversary *)

module type Oracle = {
  proc f (x:int) : int 
}.

module type Adv (O:Oracle) = {
  proc a (z:int) : int 
}.

module M8 (A:Adv) = {
  proc g1 (x : int) : int = {
    var r : int;
    r <@ A(M6).a(0); 
    return r + x;
  }

  proc g2 (x: int) : int = {
    var r : int;
    M7.z <- 3;
    r <@ A(M7).a(0); 
    return x + r;
  }
}.

(* 

 * (A <: Adv {M7}) : means A can be any module of type Adv that 
    does not use global variables of M7 (i.e M7.z)

 * (glob A) is the global memory of A 

*)

equiv M8_g1_g2 (A<:Adv {M7}) : M8(A).g1 ~ M8(A).g2 : ={x, glob A} ==> ={res, glob A}.
proof.
  proc.
  call (_: M7.z{2} = 3). (* Call rule for adversary expect an invariant *)
  + admit.
  admit.
qed.

(* We remove the annotation {M7} *)
(*
equiv M8_g1_g2 (A<:Adv) : M8(A).g1 ~ M8(A).g2 : ={x, glob A} ==> ={res, glob A}.
proof.
  proc.
  call (_: M7.z{2} = 3). 
*)

(* Deduce fact on probabilities *)

lemma myPr (A<:Adv{M7}) &m x0: Pr[ M8(A).g1(x0) @ &m : res = 17 ] = Pr[ M8(A).g2(x0) @ &m : res = 17].
proof.
  byequiv (_: ={x, glob A} ==> ={res, glob A}).
  + apply (M8_g1_g2 A). 
  (* Precondition is true *)
  + by move=> />.
  (* Post condition implies equality of events *)
  by move=> />.
qed.

lemma myPr1 (A<:Adv{M7}) &m x0: Pr[ M8(A).g1(x0) @ &m : res = 17 ] = Pr[ M8(A).g2(x0) @ &m : res = 17].
proof.
  byequiv. (* pre and post are infered *)
  + conseq (M8_g1_g2 A). 
    + by move=> />. 
    + by move=> />.
  + by move=> />.
  by move=> />.  
qed.

lemma myPr2 (A<:Adv{M7}) &m x0: Pr[ M8(A).g1(x0) @ &m : res = 17 ] = Pr[ M8(A).g2(x0) @ &m : res = 17].
proof.
  by byequiv (M8_g1_g2 A).
qed.

lemma myPr_le (A<:Adv{M7}) &m x0: 
  Pr[ M8(A).g1(x0) @ &m : res = 17 ] <= Pr[ M8(A).g2(x0) @ &m : 17 <= res].
proof.
  byequiv.
  + by conseq (M8_g1_g2 A).
  + by move=> />.
  (* post condition implies res{1} = 17 implies 17 <= res{2} *)
  move=> />.
qed.
  
(* ******************************************************* *)
(* Playing with random rule                                *)

require import DBool.

module R = {
  proc f () : bool = {
    var r;
    r <$ {0,1};
    return r;
  }
}.

equiv R_f_v1 : R.f ~ R.f : true ==> res{1} = res{2}.
proof.
  proc. 
  rnd (fun b => b) (fun b => b).  (* The random rule take a function and its inverse *)
  skip.
  move=> />.
qed.

equiv R_f_v2 : R.f ~ R.f : true ==> res{1} = res{2}.
proof.
  proc. 
  rnd.  (* When no argument is provided the functions are the identity *)
  skip.
  move=> />.
qed.

equiv R_f_v3 : R.f ~ R.f : true ==> res{1} <> res{2}.
proof.
  proc. 
  rnd (fun b => !b) (fun b => !b).  
  skip.
  move=> />.
  smt (@DBool). (* Gives all the lemma in DBool to smt solver *)
qed.

equiv R_f_v4 : R.f ~ R.f : true ==> res{1} <> res{2}.
proof.
  proc. 
  rnd (fun b => !b). (* When the function is involutive, it is not necessary to provide the inverse *)  
  skip.
  move=> />.
  smt (@DBool). (* Gives all the lemma in DBool to smt solver *)
qed.

require import DInterval.
module R1 = {
  proc f () : int = {
    var r;
    r <$ [0..5];
    return r + 5;
  }

  proc g () : int = {
    var r;
    r <$ [3..8];
    return r + 2;
  }
  
}.

equiv R1_f_g : R1.f ~ R1.g : true ==> ={res}.
proof.
  proc.
  rnd (fun x => x + 3) (fun x => x - 3).
  skip.
  smt (@DInterval).
qed.

(* swap tactic *)

module R2 = {
  proc t () : int = {
    var i1, i2, i3, i4 : int;
    i1 = 1;
    i2 = 2;
    i3 = 3;
    i4 = i1 + i2 + i3;
    return i3;
  }

  proc f1 () : bool * bool = {
    var r1, r2: bool;
    r1 <$ {0,1};
    r2 <$ {0,1};
    return (r1, r2); 
  }

  proc f2 () : bool * bool = {
    var r1, r2: bool;
    r1 <$ {0,1};
    r2 <$ {0,1};
    return (r2, r1); 
  }

  proc f3 () : bool * bool = {
    var r1, r2: bool;
    r2 <$ {0,1};
    r1 <$ {0,1};
    return (r1, !r2); 
  }

  proc f4(b:bool) : bool * bool = {
    var r1, r2: bool;
    if (b) {
      r1 <$ {0,1};
      r2 <$ {0,1};
    } else {
      r2 <$ {0,1};
      r1 <$ {0,1};
      r2 <- r1 ^ r2;
    }
    return (r1, r2);
  }
}.

(* Try to understand the swap tactic *)
equiv R2_t : R2.t ~ R2.t : true ==> ={res}.
proof.
  proc.
  swap {1} 2 1.
  swap {1} 2 -1.
  swap {2} 1 2. 
  swap {1} 1 2.
  (* Can you do swap {1} 3 1, or swap {1} 4 -2 ? *)
  auto.
qed.

(* Using swap and random *)
equiv R2_f1_f2 : R2.f1 ~ R2.f2 : true ==> ={res}.
proof.
  proc.
  admit.
qed.

equiv R2_f1_f3 : R2.f2 ~ R2.f3 : true ==> ={res}.
proof.
  proc.
  admit.
qed.

(* This one is harder *)
equiv R2_f1_f4 : R2.f1 ~ R2.f4 : true ==> ={res}.
proof.
  proc.
  admit.
qed.


(* Your are ready to prove the exact security of Elgamal encryption scheme:
   open the file Elgamal.ec *)

